# Job Description: Product Manager

**Company:** [COMPANY NAME]  
**Location:** [CITY / Remote / Hybrid]  
**Type:** Full-time  
**Salary:** €[MIN] – €[MAX] per year  
**Reports to:** [CPO / CTO / CEO]

---

## About [COMPANY NAME]

[2-3 sentences about company, product, and mission.]

---

## The Role

We're looking for a Product Manager to [CORE MISSION — e.g., "own our core [PRODUCT AREA] from discovery to ship"]. You'll work directly with engineering, design, and customers to define what gets built and why.

This is a [IC / LEAD] role — you'll [own one product area / manage a small team of PMs / be the first PM hire].

---

## What You'll Do

- **Strategy:** Develop and maintain the product roadmap for [AREA], grounded in customer research and business goals
- **Discovery:** Run customer interviews, analyze usage data, and synthesize insights into clear problem statements
- **Prioritization:** Make and communicate hard prioritization decisions using [FRAMEWORK — e.g., "RICE / opportunity sizing / user impact"]
- **Delivery:** Write crisp, complete specs; work with engineering daily to unblock; make scope tradeoffs without drama
- **Launch:** Coordinate launches across marketing, CS, and sales; define success metrics; own post-launch learning cycles
- **Metrics:** Own the KPIs for your product area and report on them weekly

---

## What We're Looking For

**Must-have:**
- [X]+ years of product management experience shipping software products
- Demonstrated ability to conduct customer research and turn insights into roadmap decisions
- Strong written communication — your PRDs are clear enough that engineering doesn't need to ask obvious questions
- Comfortable with data — can write basic SQL or use BI tools to answer your own questions
- Low ego about scope — you care about outcomes, not ownership

**Nice-to-have:**
- Technical background (engineering or data science)
- Experience in [YOUR DOMAIN / INDUSTRY]
- [ADDITIONAL SKILL]

---

## What We Offer

- **Salary:** €[MIN] – €[MAX]
- **Equity:** [X]%
- **Remote:** [POLICY]
- **PTO:** [X] days
- **Learning:** €[X]/year
- **[OTHER BENEFIT]**

---

## Interview Process

1. Application review
2. 30-min screen call
3. Product case (~2 hours take-home): [DESCRIBE — e.g., "Prioritize a backlog of fictional features and write a one-page PRD for your top pick"]
4. 90-min loop (design, engineering, business stakeholder)
5. 30-min final with [CEO / CPO]
6. Offer

---

## How to Apply

Email [EMAIL] with subject: **"PM Role — [YOUR NAME]"**

Tell us: **"What's a product decision you made that you'd make differently today, and why?"** (3-5 sentences)

*[COMPANY] is an equal opportunity employer.*
