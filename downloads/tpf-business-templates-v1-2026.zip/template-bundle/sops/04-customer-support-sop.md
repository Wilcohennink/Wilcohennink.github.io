# SOP: Customer Support Operations

**Version:** 1.0  
**Owner:** [Support Lead / Head of Customer Success]  
**Last updated:** [DATE]

---

## Purpose

To ensure every customer support interaction is resolved quickly, consistently, and in a way that strengthens the customer relationship.

---

## Support Tiers

| Tier | Issue Type | SLA (First Response) | SLA (Resolution) | Owner |
|------|-----------|---------------------|-----------------|-------|
| Tier 1 | Common questions, how-to | [X] hours | [X] hours | [Support Agent] |
| Tier 2 | Account issues, billing, bugs | [X] hours | [X] business days | [Senior Support / CS Manager] |
| Tier 3 | Critical bugs, data loss, security | [X] minutes | [X] hours | [Engineering + CS Lead] |

**Business hours:** [MON–FRI, TIME–TIME, TIMEZONE]  
**After-hours coverage:** [YES/NO — if yes, describe who covers]

---

## Channels & Tools

| Channel | Tool | Priority | Owner |
|---------|------|----------|-------|
| Email | [HELPDESK TOOL — e.g., Intercom, Zendesk, Help Scout] | Primary | [ROLE] |
| Live chat | [TOOL] | High | [ROLE] |
| In-app | [TOOL] | High | [ROLE] |
| Social (Twitter/X DM) | [TOOL] | Medium | [ROLE] |
| Phone | [TOOL / N/A] | [PRIORITY] | [ROLE] |

---

## Triage Process

### On every new ticket:

1. **Categorize** using tags: `bug`, `billing`, `how-to`, `feature-request`, `complaint`, `other`
2. **Assess severity:**
   - **Critical:** Service down, data loss, security issue → Tier 3 immediately
   - **High:** Core feature broken, blocking customer workflow → Tier 2
   - **Normal:** Question, minor issue, non-blocking → Tier 1
3. **Assign** to appropriate team member
4. **Send acknowledgment** (auto or manual) within [X] minutes

**Acknowledgment template:**
```
Subject: Re: [THEIR SUBJECT]

Hi [NAME],

Thanks for reaching out. I've received your message and I'm on it.

Expected response: [SLA TIME — e.g., "within 4 business hours"]

In the meantime, our docs may help: [DOCS URL]

[YOUR NAME]
Support Team, [COMPANY]
```

---

## Response Guidelines

### Tone Standards
- **Professional but warm** — not robotic, not overly casual
- **Empathize first** — acknowledge the frustration before solving
- **Be concrete** — give step-by-step instructions, not vague advice
- **Own the problem** — never blame the customer or a third party

### Forbidden phrases
- "As per my previous email..."
- "Unfortunately, that's not possible..."
- "That's not how it works..."
- "You should have..." / "You need to..."

### Required elements in every response
1. Personalized greeting (use their name)
2. Acknowledgment of the specific issue
3. Clear solution or next step
4. Offer to follow up

---

## Common Issue Scripts

### Password reset
```
Hi [NAME],

To reset your password:
1. Go to [URL]
2. Click "Forgot password"
3. Enter your email address: [THEIR EMAIL]
4. Check your inbox for a reset link (also check spam)

The link expires in 24 hours. Let me know if you don't receive it within 5 minutes and I'll trigger one manually.

[YOUR NAME]
```

### Billing dispute
```
Hi [NAME],

I'm sorry for the confusion on your bill. Let me look into this right now.

[AFTER CHECKING:]

I can see that [EXPLANATION OF WHAT HAPPENED]. Here's what I'll do:
- [CREDIT/REFUND/ADJUSTMENT]
- This will appear on your [NEXT STATEMENT / WITHIN X DAYS]

You'll receive a confirmation email from our billing system. Is there anything else I can help with?

[YOUR NAME]
```

### Bug report acknowledgment
```
Hi [NAME],

Thank you for reporting this — this is exactly the kind of feedback that helps us improve.

I've logged this as a bug with our engineering team ([INTERNAL TICKET ID: #XXX]). Based on severity, the expected fix timeline is [TIMEFRAME].

I'll email you personally when it's resolved. If this is blocking critical work for you right now, here's a workaround: [WORKAROUND if available / "I'll escalate this to get a faster resolution" if not].

[YOUR NAME]
```

---

## Escalation Path

```
Tier 1 Agent
    ↓ (can't resolve or SLA breached)
Tier 2 Senior Support / CS Manager
    ↓ (requires engineering or executive involvement)
Tier 3 Engineering / CS Lead / Founder
```

**When to escalate:**
- Customer has asked for a manager
- Issue has been open >2x the SLA
- Customer mentions legal action, public complaint, or media
- Any data breach or security concern

**When escalating, always include:**
- Full ticket history
- What was already tried
- Customer's sentiment (calm / frustrated / threatening)
- Your recommended resolution

---

## Quality Assurance

**Weekly:**
- [ ] [SUPPORT LEAD] reviews random sample of [X] tickets
- [ ] Score each on: Response time, Accuracy, Tone, Resolution rate
- [ ] Flag examples (positive and negative) for team learning

**Monthly:**
- [ ] Calculate CSAT from post-resolution surveys
- [ ] Review top issue categories → escalate patterns to Product team
- [ ] Update this SOP with any new scripts or decision changes

**CSAT target:** [X%]  
**First Contact Resolution target:** [X%]

---

## Tools Reference

| Tool | Purpose | Access |
|------|---------|--------|
| [HELPDESK] | Primary support inbox | [URL] |
| [INTERNAL KNOWLEDGE BASE] | Answers and docs | [URL] |
| [CRM] | Customer history | [URL] |
| [BUG TRACKER] | Log and track bugs | [URL] |
| [TEAM CHAT] | Escalation and discussion | [CHANNEL] |

---

## Version History

| Version | Date | Changed by | Change |
|---------|------|------------|--------|
| 1.0 | [DATE] | [NAME] | Initial version |
