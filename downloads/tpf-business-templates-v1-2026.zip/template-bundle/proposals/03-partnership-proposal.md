# Partnership Proposal: [PARTNERSHIP NAME]

**From:** [YOUR NAME], [YOUR COMPANY]  
**To:** [PARTNER NAME], [PARTNER COMPANY]  
**Date:** [DATE]

---

## The Opportunity

[YOUR COMPANY] and [PARTNER COMPANY] serve overlapping audiences without directly competing. A structured partnership could benefit both sides significantly.

**Audience overlap:**
- [YOUR AUDIENCE]: [X] [DESCRIPTION — e.g., "indie SaaS founders with <$1M ARR"]
- [THEIR AUDIENCE]: [X] [DESCRIPTION]
- **Overlap estimate:** ~[X%] of each other's audience

---

## Proposed Partnership Structure

### Option A: Affiliate / Revenue Share Partnership

| Term | Details |
|------|---------|
| [YOUR PRODUCT] commission | [X%] per sale attributed to [PARTNER] |
| [THEIR PRODUCT] commission | [X%] per sale attributed to [YOUR COMPANY] |
| Attribution window | [X days] |
| Payout | [Monthly on the 1st / per transaction] |
| Minimum payout | €[AMOUNT] |

**Estimated monthly earnings for [PARTNER COMPANY]:** €[LOW] – €[HIGH] based on [X] conversions/month at [X%] conversion rate

### Option B: Co-Marketing Partnership

| Activity | [YOUR COMPANY] provides | [PARTNER] provides |
|----------|------------------------|-------------------|
| Email feature | [X] subscribers | [X] subscribers |
| Social post | [PLATFORM, X followers] | [PLATFORM, X followers] |
| Content | [WHAT YOU'LL CREATE] | [WHAT THEY CREATE] |
| Webinar/event | [YOUR ROLE] | [THEIR ROLE] |

### Option C: Integration / Technical Partnership

[IF APPLICABLE — describe the technical integration, who builds what, and mutual benefits]

---

## What's In It For [PARTNER COMPANY]

- **Revenue:** [SPECIFIC EARNING ESTIMATE]
- **Audience growth:** Access to [YOUR COMPANY]'s [X] [AUDIENCE DESCRIPTION]
- **Credibility:** Association with [YOUR COMPANY]'s reputation in [SPACE]
- **[OTHER BENEFIT]:** [DESCRIPTION]

---

## What [YOUR COMPANY] Provides

- Dedicated partner dashboard / tracking link
- Co-branded marketing assets
- Priority support for your referred customers
- [SPECIFIC RESOURCE — e.g., "A dedicated Slack channel for partner questions"]
- Quarterly performance reviews and optimization calls

---

## Proposed Terms

- **Duration:** 12 months, auto-renewing
- **Exclusivity:** [NON-EXCLUSIVE / EXCLUSIVE IN X CATEGORY]
- **Termination:** Either party can terminate with 30 days written notice
- **Data:** Each party owns their customer data; no sharing of PII without consent

---

## Performance Targets (Year 1)

| Metric | Target |
|--------|--------|
| Referrals to [YOUR COMPANY] | [X/month] |
| Referrals to [PARTNER] | [X/month] |
| Joint revenue generated | €[TARGET] |
| Co-marketing reach | [X people] |

---

## How to Get Started

1. **[DATE]:** 30-min partnership alignment call — [CALENDAR LINK]
2. **[DATE]:** Review and sign partnership agreement
3. **[DATE]:** Technical setup (tracking links, assets delivered)
4. **[DATE]:** First co-marketing activation

I'm flexible on the terms — happy to adjust any element to make this work for both teams.

---

*[YOUR NAME] | [EMAIL] | [PHONE]*
