# Job Description: Operations Manager

**Company:** [COMPANY NAME]  
**Location:** [CITY / Remote / Hybrid]  
**Type:** Full-time  
**Salary:** €[MIN] – €[MAX] per year  
**Reports to:** [COO / CEO]

---

## About [COMPANY NAME]

[2-3 sentences about company, growth stage, and why operations matters to you right now.]

---

## The Role

We're looking for an Operations Manager to [CORE MISSION — e.g., "build and run the internal systems that let [COMPANY] scale without chaos"]. 

As our [first operations hire / operations lead], you'll own everything from vendor relationships and tool procurement to process documentation and cross-team coordination. If something isn't working efficiently, it's yours to fix.

---

## What You'll Do

- **Process:** Document, optimize, and enforce core business processes across [TEAMS/AREAS]
- **Tools & systems:** Own our internal tool stack — evaluate, implement, and integrate the systems the team relies on
- **Vendors:** Manage relationships and contracts with [key vendor categories]
- **Data & reporting:** Build and maintain the operational dashboards leadership reviews weekly
- **Projects:** Lead internal cross-functional projects that don't have an obvious owner
- **Finance ops:** [BOOKKEEPING / EXPENSE MANAGEMENT / ACCOUNTS PAYABLE — if applicable]
- **HR ops:** [ONBOARDING LOGISTICS / PAYROLL COORDINATION — if applicable]

---

## What We're Looking For

**Must-have:**
- [X]+ years in an operations, chief of staff, or similar role — ideally at a fast-growing startup
- Strong systems thinker — you build processes that actually get followed
- Extremely organized with high attention to detail
- Proactive communicator — you surface problems early, not after they blow up
- Comfortable with ambiguity — many of your problems won't have obvious right answers

**Nice-to-have:**
- Experience with [RELEVANT TOOLS — e.g., Notion, Linear, Airtable, Zapier, etc.]
- Background in [RELEVANT DOMAIN — e.g., finance ops, HR ops, supply chain]
- [OTHER SKILL]

---

## What We Offer

- **Salary:** €[MIN] – €[MAX]
- **Equity:** [X]% (if applicable)
- **Remote:** [POLICY]
- **PTO:** [X] days
- **Learning:** €[X]/year
- **[OTHER BENEFIT]**

---

## Interview Process

1. Application review
2. 30-min screen call
3. Take-home exercise (~1 hour): [DESCRIBE — e.g., "Review a messy process description and propose a cleaner version with an implementation plan"]
4. 60-min interview with [HIRING MANAGER] + [TEAM MEMBER]
5. Offer

---

## How to Apply

Email [EMAIL] with subject: **"Ops Manager — [YOUR NAME]"**

Tell us: **"Describe a broken process you fixed. What was wrong, what did you do, and what was the result?"** (3-5 sentences)

*[COMPANY] is an equal opportunity employer.*
