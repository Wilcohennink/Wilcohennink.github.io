# Ultimate Business Template Pack

**60+ professional templates for freelancers, founders, and growing teams.**  
*Stop starting from a blank page. Copy, customize, ship.*

---

## What's Inside

This pack contains everything you need to run a professional business — from the first client email to the quarterly OKR review. Every template is designed to be opened, filled in, and sent. No design skills required.

### Email Templates (10 sequences)

| Template | What It Does |
|----------|-------------|
| `01-cold-outreach.html` | 3-email cold outreach sequence with follow-up and breakup email |
| `02-onboarding-sequence.html` | 5-email new customer onboarding sequence |
| `03-follow-up-sequence.html` | 4-email post-demo / post-proposal follow-up |
| `04-re-engagement.html` | 3-email win-back sequence for lapsed customers |
| `05-referral-request.html` | 2-email referral / word-of-mouth activation sequence |
| `06-churn-prevention.html` | 3-email cancellation recovery sequence |
| `07-product-launch.html` | 5-email product launch sequence (teaser through close) |
| `08-newsletter-template.html` | Full-featured newsletter template (weekly or monthly) |
| `09-abandoned-cart.html` | 3-email checkout recovery sequence |
| `10-partnership-outreach.html` | 3 partnership templates (affiliate, content collab, co-promo) |

### Proposals (3 templates)

| Template | What It Does |
|----------|-------------|
| `01-freelance-project-proposal.md` | Full project proposal for freelancers and agencies |
| `02-saas-sales-proposal.md` | B2B SaaS sales proposal with ROI calculator |
| `03-partnership-proposal.md` | Structured partnership / co-marketing proposal |

### Standard Operating Procedures — SOPs (5 templates)

| Template | What It Does |
|----------|-------------|
| `01-client-onboarding-sop.md` | Step-by-step client onboarding (contract → 30-day check-in) |
| `02-content-creation-sop.md` | Content creation and publishing process |
| `03-hiring-and-interviews-sop.md` | Full hiring process: job post, screening, interviews, offer |
| `04-customer-support-sop.md` | Support triage, scripts, escalation, and QA |
| `05-social-media-sop.md` | Social media calendar, content process, and post templates |

### Job Descriptions (5 templates)

| Template | What It Does |
|----------|-------------|
| `01-software-engineer.md` | Engineering hire (adaptable to any level) |
| `02-marketing-manager.md` | Marketing manager / generalist |
| `03-customer-success-manager.md` | CSM with metrics and OTE structure |
| `04-product-manager.md` | PM role with process and interview format |
| `05-operations-manager.md` | Ops / chief of staff role |

### Business Documents (6 templates)

| Template | What It Does |
|----------|-------------|
| `01-meeting-agenda-and-notes.md` | Full meeting template: agenda, notes, decisions, action items |
| `02-project-brief.md` | Complete project brief with scope, risks, and success metrics |
| `03-invoice-template.md` | Professional invoice with bank and payment details |
| `04-weekly-report-template.md` | Weekly team/individual status report |
| `05-okr-template.md` | Full OKR setup with quarterly tracking table |
| `06-press-release-template.md` | Standard press release format |

---

## How to Use These Templates

### Email templates (.html files)

1. Open the `.html` file in any text editor or your email tool's HTML editor
2. Search for `[PLACEHOLDERS]` — every placeholder is in `[SQUARE BRACKETS]`
3. Replace all placeholders with your content
4. Copy/paste into your email tool (Mailchimp, Beehiiv, ConvertKit, Gmail, etc.)
5. Send a test to yourself before going live

**Tip:** The yellow-highlighted placeholders in the rendered HTML make it easy to see what's missing at a glance.

### Document templates (.md files)

1. Open in any Markdown editor (Notion, Obsidian, VS Code, Typora, or even a text editor)
2. Replace all `[PLACEHOLDERS]` with your content
3. Export to PDF for client-facing documents, or keep as Markdown in your internal docs

**Recommended tools:**
- **Notion:** Paste Markdown directly (it converts automatically)
- **Google Docs:** Use "File → Import" or paste with formatting
- **VS Code:** Open .md file, press Cmd+Shift+V for preview

---

## Quick Start: Which Template to Use First?

**If you're a freelancer just starting out:**  
→ Start with `proposals/01-freelance-project-proposal.md` and `business-docs/03-invoice-template.md`

**If you're launching a product:**  
→ Start with `email-templates/07-product-launch.html`

**If you're building a team:**  
→ Start with `job-descriptions/01-software-engineer.md` and `sops/03-hiring-and-interviews-sop.md`

**If you're scaling customer operations:**  
→ Start with `sops/01-client-onboarding-sop.md` and `sops/04-customer-support-sop.md`

**If you just got a meeting with a big prospect:**  
→ Start with `proposals/02-saas-sales-proposal.md`

---

## What Makes These Templates Different

**Specificity over generality.** Every template includes concrete examples, not just vague placeholder text. You'll see what a real answer looks like.

**Opinionated structure.** These aren't blank forms — they reflect hard-won decisions about what to include, what to skip, and why. Each template has been designed around the most common version of the task.

**Ready to send.** The email templates use clean, tested HTML that renders correctly in Gmail, Outlook, Apple Mail, and marketing platforms. No broken formatting.

**Markdown for everything else.** All document templates use Markdown — works everywhere, version-controls cleanly in Git, exports to PDF cleanly.

---

## Customization Tips

- **Find all placeholders at once:** Search for `[` in any template — every placeholder starts with a bracket
- **Adapt to your brand:** Email templates use CSS variables at the top — change the accent color in one place to match your brand
- **Build a library:** Save your filled-in versions as "master templates" for your company — you'll only need to customize once per template type

---

## File Structure

```
template-bundle/
├── README.md                          ← You are here
├── email-templates/
│   ├── 01-cold-outreach.html
│   ├── 02-onboarding-sequence.html
│   ├── 03-follow-up-sequence.html
│   ├── 04-re-engagement.html
│   ├── 05-referral-request.html
│   ├── 06-churn-prevention.html
│   ├── 07-product-launch.html
│   ├── 08-newsletter-template.html
│   ├── 09-abandoned-cart.html
│   └── 10-partnership-outreach.html
├── proposals/
│   ├── 01-freelance-project-proposal.md
│   ├── 02-saas-sales-proposal.md
│   └── 03-partnership-proposal.md
├── sops/
│   ├── 01-client-onboarding-sop.md
│   ├── 02-content-creation-sop.md
│   ├── 03-hiring-and-interviews-sop.md
│   ├── 04-customer-support-sop.md
│   └── 05-social-media-sop.md
├── job-descriptions/
│   ├── 01-software-engineer.md
│   ├── 02-marketing-manager.md
│   ├── 03-customer-success-manager.md
│   ├── 04-product-manager.md
│   └── 05-operations-manager.md
└── business-docs/
    ├── 01-meeting-agenda-and-notes.md
    ├── 02-project-brief.md
    ├── 03-invoice-template.md
    ├── 04-weekly-report-template.md
    ├── 05-okr-template.md
    └── 06-press-release-template.md
```

---

## License

Personal and commercial use permitted. Redistribute or resell requires a separate license.  
© [YEAR] — All rights reserved.

---

## Support

Questions? Email: [YOUR SUPPORT EMAIL]  
Updates and new templates: [YOUR WEBSITE / GUMROAD PAGE]

---

*Built for people who'd rather spend time building their business than formatting documents.*
