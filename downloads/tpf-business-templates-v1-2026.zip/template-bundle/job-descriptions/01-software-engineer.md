# Job Description: Software Engineer ([LEVEL: Junior / Mid / Senior])

**Company:** [COMPANY NAME]  
**Location:** [CITY / Remote / Hybrid]  
**Type:** Full-time  
**Salary:** €[MIN] – €[MAX] per year  
**Reports to:** [ENGINEERING MANAGER / CTO]

---

## About [COMPANY NAME]

[2-3 sentences: what you do, who you serve, and one proof point of traction — e.g., "X,000 customers", "backed by X", "€Xm ARR"]. 

We're [TEAM SIZE] people, and we're [GROWTH STAGE — e.g., "growing fast and just closed our Series A"].

---

## The Role

We're looking for a [LEVEL] Software Engineer to [CORE MISSION IN ONE SENTENCE — e.g., "own and evolve our core data pipeline from ingestion to customer-facing APIs"].

You'll be working on [SPECIFIC AREA — e.g., "our backend services in Python and Go, with some infrastructure work in Terraform"]. The most important project on your plate in the first 90 days will be [SPECIFIC PROJECT].

---

## What You'll Do

- [RESPONSIBILITY 1 — specific and honest, e.g., "Design and ship features end-to-end: backend API, frontend integration, and deployment"]
- [RESPONSIBILITY 2 — e.g., "Participate in on-call rotation (currently low-frequency — ~1 incident/month)"]
- [RESPONSIBILITY 3 — e.g., "Review code from peers and give actionable, kind feedback"]
- [RESPONSIBILITY 4 — e.g., "Work directly with product and customers to define solutions, not just implement specs"]
- [RESPONSIBILITY 5 — e.g., "Improve the reliability and observability of systems you own"]

---

## What We're Looking For

**Must-have:**
- [X]+ years of professional software development experience
- Strong proficiency in [PRIMARY LANGUAGE(S) — e.g., Python, TypeScript]
- Experience building and operating [SYSTEM TYPE — e.g., "RESTful APIs at production scale"]
- [TECHNICAL SKILL — e.g., "Comfortable with SQL and relational database design"]
- [SOFT SKILL — e.g., "Communicates technical concepts clearly to non-engineers"]

**Nice-to-have:**
- Experience with [FRAMEWORK/TOOL]
- Familiarity with [INDUSTRY/DOMAIN KNOWLEDGE]
- [ADDITIONAL SKILL]

**We don't require:**
- A computer science degree
- Experience at a big tech company
- [COMMON REQUIREMENT YOU'RE WAIVING — be specific about what you don't care about]

---

## Our Stack

- **Backend:** [LANGUAGES / FRAMEWORKS]
- **Frontend:** [FRAMEWORKS / TOOLS]
- **Database:** [DATABASES]
- **Infrastructure:** [CLOUD / IaC TOOLS]
- **CI/CD:** [TOOLS]
- **Observability:** [MONITORING / LOGGING TOOLS]

*You don't need to know everything here — we care more about solid fundamentals and learning ability than specific tool experience.*

---

## What We Offer

- **Salary:** €[MIN] – €[MAX] depending on experience
- **Equity:** [X]% options ([CLIFF / VESTING SCHEDULE])
- **Remote:** [FULLY REMOTE / HYBRID — describe expectations]
- **PTO:** [X] days + [PUBLIC HOLIDAYS] + [SICK LEAVE POLICY]
- **Equipment:** €[X] home office / equipment budget
- **Learning:** €[X]/year for courses, books, conferences
- **Health:** [HEALTH INSURANCE / PENSION — if applicable]
- **[OTHER BENEFIT]:** [DESCRIPTION]

---

## Interview Process

1. **Application review** — we respond to every application within [X] business days
2. **Screen call** (30 min) — with [RECRUITER / HIRING MANAGER]
3. **Technical assessment** — [TAKE-HOME / LIVE CODING / SYSTEM DESIGN] (~[X] hours)
4. **Team interview** (60 min) — meet [X] team members
5. **Offer**

Total process: typically [X] weeks from application to offer.

---

## How to Apply

Send your CV to [EMAIL] with the subject line: **"[ROLE] — [YOUR NAME]"**

Include a short note (3-5 sentences) answering: **[SPECIFIC SCREENING QUESTION — e.g., "What's the most technically complex problem you've solved, and what was your approach?"]**

No cover letter needed. We value specificity over polish.

*[COMPANY NAME] is an equal opportunity employer. We actively work to build a diverse team and welcome applicants of all backgrounds.*
