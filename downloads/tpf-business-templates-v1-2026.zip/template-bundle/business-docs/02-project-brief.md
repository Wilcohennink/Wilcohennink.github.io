# Project Brief: [PROJECT NAME]

**Version:** 1.0  
**Created:** [DATE]  
**Owner:** [PROJECT OWNER NAME, TITLE]  
**Status:** [DRAFT / APPROVED / IN PROGRESS]

---

## One-Liner

[Describe the project in one sentence: what we're building, for whom, and why it matters now.]

---

## Background & Context

[2-4 paragraphs. What's the situation? What problem or opportunity drove this project? What have we already tried? Why now?]

---

## Goals

### Primary goal
[The single most important outcome this project must achieve — be specific and measurable.]

### Secondary goals (nice-to-have)
1. [GOAL]
2. [GOAL]

### Non-goals (explicitly out of scope)
1. [WHAT THIS PROJECT DOES NOT ADDRESS — this is important]
2. [WHAT THIS PROJECT DOES NOT ADDRESS]

---

## Success Metrics

| Metric | Baseline | Target | Measurement method |
|--------|----------|--------|--------------------|
| [METRIC 1] | [CURRENT] | [TARGET] | [HOW/WHEN MEASURED] |
| [METRIC 2] | [CURRENT] | [TARGET] | [HOW/WHEN MEASURED] |
| [METRIC 3] | [CURRENT] | [TARGET] | [HOW/WHEN MEASURED] |

---

## Scope

### In scope
- [DELIVERABLE 1]
- [DELIVERABLE 2]
- [DELIVERABLE 3]

### Out of scope
- [EXCLUDED ITEM]
- [EXCLUDED ITEM]

---

## Proposed Approach

[2-4 paragraphs on the approach. Focus on the "why this way" not just "what". Mention key trade-offs and why this approach was chosen over alternatives.]

**Key phases:**
1. **[PHASE NAME]** (Week X–Y): [WHAT HAPPENS]
2. **[PHASE NAME]** (Week X–Y): [WHAT HAPPENS]
3. **[PHASE NAME]** (Week X–Y): [WHAT HAPPENS]

---

## Team & Responsibilities

| Name | Role | Responsibility |
|------|------|---------------|
| [NAME] | [TITLE] | Decision authority on [X] |
| [NAME] | [TITLE] | Execution lead for [X] |
| [NAME] | [TITLE] | [RESPONSIBILITY] |
| [NAME] | [TITLE] | [RESPONSIBILITY] |

**Decision-maker:** [NAME] — final call on [SCOPE / BUDGET / DESIGN / ETC.]  
**Day-to-day lead:** [NAME]

---

## Timeline

| Milestone | Date | Owner |
|-----------|------|-------|
| Brief approved | [DATE] | [NAME] |
| [MILESTONE 2] | [DATE] | [NAME] |
| [MILESTONE 3] | [DATE] | [NAME] |
| Launch / delivery | [DATE] | [NAME] |
| Post-launch review | [DATE] | [NAME] |

---

## Budget

| Item | Estimated cost |
|------|---------------|
| [ITEM] | €[AMOUNT] |
| [ITEM] | €[AMOUNT] |
| [ITEM] | €[AMOUNT] |
| **Total** | **€[TOTAL]** |

**Budget owner:** [NAME]  
**Approval required from:** [NAME / ROLE] for spend above €[THRESHOLD]

---

## Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| [RISK 1] | [High/Med/Low] | [High/Med/Low] | [HOW YOU'LL HANDLE IT] |
| [RISK 2] | [H/M/L] | [H/M/L] | [MITIGATION] |
| [RISK 3] | [H/M/L] | [H/M/L] | [MITIGATION] |

---

## Dependencies

| Dependency | Owner | Status | Needed by |
|-----------|-------|--------|----------|
| [DEPENDENCY — e.g., "API from third-party vendor"] | [OWNER] | [STATUS] | [DATE] |
| [DEPENDENCY] | [OWNER] | [STATUS] | [DATE] |

---

## Stakeholders & Communication

| Stakeholder | Interest | Communication cadence |
|------------|---------|----------------------|
| [STAKEHOLDER] | [WHAT THEY CARE ABOUT] | [Weekly update / monthly / on milestone] |
| [STAKEHOLDER] | [WHAT THEY CARE ABOUT] | [CADENCE] |

---

## Open Questions

- [ ] [QUESTION THAT NEEDS ANSWERING BEFORE WORK CAN BEGIN]
- [ ] [QUESTION]

---

## Appendix

[Any supporting data, research, mockups, or relevant background documents — link here]

- [LINK 1: DOCUMENT NAME]
- [LINK 2: DOCUMENT NAME]
