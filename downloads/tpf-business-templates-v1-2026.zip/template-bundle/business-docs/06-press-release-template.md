# PRESS RELEASE

**FOR IMMEDIATE RELEASE** / **EMBARGO UNTIL [DATE]**

---

## [COMPANY NAME] [LAUNCHES / RAISES / PARTNERS WITH / ACHIEVES] [WHAT]

*[TAGLINE — One compelling sentence that summarizes the announcement in a way that a journalist can use as a subtitle]*

**[CITY, DATE]** — [COMPANY NAME], [BRIEF COMPANY DESCRIPTION — what you do and for whom], today announced [THE NEWS IN ONE SENTENCE — who, what, when/where, why it matters].

[PARAGRAPH 2 — Expand on the news. What exactly is being announced? Key details: amount raised, product features, partnership scope, milestone achieved. Keep it factual and specific.]

[PARAGRAPH 3 — Context: Why does this matter? What problem does it solve? What's the market context? This paragraph is where journalists find the "why should readers care" angle. Keep it compelling but factual.]

**Quote from company leader:**

> "[QUOTE FROM CEO / FOUNDER — make it forward-looking, specific, and human. Not generic PR speak. E.g., 'We've spent two years talking to [X] customers who told us [SPECIFIC PAIN]. This launch is our answer — and based on the beta results, it works.']"
>
> — [NAME], [TITLE], [COMPANY NAME]

[PARAGRAPH 4 — Additional details. Supporting facts, customer traction, partner details, or feature specifics that reinforce the announcement. Include a second quote here if applicable.]

**Quote from partner / customer / investor (if applicable):**

> "[QUOTE FROM EXTERNAL PARTY — validates the announcement from a third party perspective]"
>
> — [NAME], [TITLE], [ORGANIZATION]

[PARAGRAPH 5 — Availability / next steps. When is this available? Where? What's the price? How do interested parties engage? Keep it actionable.]

---

## About [COMPANY NAME]

[BOILERPLATE — 2-3 sentences describing the company. This stays the same across all press releases. Include: what you do, who you serve, founding year, key traction metric (customers, ARR, funding), and location.]

---

## Media Contact

**[CONTACT NAME]**  
[TITLE — e.g., Head of Communications / Founder]  
[COMPANY NAME]  
[EMAIL]  
[PHONE]  
[PRESS KIT URL — logos, headshots, screenshots]

---

*[COMPANY NAME] is headquartered in [CITY] and available at [WEBSITE].*

###

*(The ### signals end of press release — industry standard)*
