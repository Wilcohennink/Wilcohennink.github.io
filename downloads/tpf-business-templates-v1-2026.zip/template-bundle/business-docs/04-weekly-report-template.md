# Weekly Report: Week of [DATE RANGE]

**Author:** [NAME]  
**Team / Function:** [TEAM]  
**Distributed to:** [MANAGER / STAKEHOLDERS]  
**Date sent:** [DATE]

---

## TL;DR (30-second read)

[2-4 bullet points. What happened this week that matters most? Write this last, after the sections below.]

- [KEY WIN OR PROGRESS]
- [KEY CHALLENGE OR BLOCKER]
- [TOP PRIORITY NEXT WEEK]

---

## Goals vs. Actuals

| Goal (set last week) | Status | Notes |
|----------------------|--------|-------|
| [GOAL 1] | ✅ Done / 🔄 In progress / ❌ Blocked / ⏭️ Deferred | [NOTE] |
| [GOAL 2] | [STATUS] | [NOTE] |
| [GOAL 3] | [STATUS] | [NOTE] |

**Completion rate:** [X/Y goals completed]

---

## Key Metrics

| Metric | Last week | This week | Change | Target |
|--------|-----------|-----------|--------|--------|
| [METRIC 1] | [VALUE] | [VALUE] | [+/-X%] | [TARGET] |
| [METRIC 2] | [VALUE] | [VALUE] | [+/-X%] | [TARGET] |
| [METRIC 3] | [VALUE] | [VALUE] | [+/-X%] | [TARGET] |

---

## What Got Done

### [PROJECT / AREA 1]
- [ACCOMPLISHMENT WITH IMPACT IF POSSIBLE — e.g., "Shipped email automation for segment X — estimated to recover ~15 churned accounts/month"]
- [ACCOMPLISHMENT]

### [PROJECT / AREA 2]
- [ACCOMPLISHMENT]
- [ACCOMPLISHMENT]

### Other
- [SMALLER WIN OR ADMIN]
- [SMALLER WIN OR ADMIN]

---

## What Didn't Get Done (and Why)

| Item | Reason not completed | Plan |
|------|---------------------|------|
| [ITEM] | [HONEST REASON — deprioritized / blocked / underestimated] | [DEFERRED TO X / DROPPED / NEEDS HELP] |
| [ITEM] | [REASON] | [PLAN] |

---

## Blockers & Escalations

| Blocker | Impact | What I need | Who can help |
|---------|--------|-------------|-------------|
| [BLOCKER] | [WHAT IT'S BLOCKING] | [SPECIFIC ASK] | [NAME] |

*(Empty if no blockers)*

---

## Next Week's Priorities

| Priority | Goal / Outcome | Due |
|----------|---------------|-----|
| 1 | [MOST IMPORTANT THING] | [DATE] |
| 2 | [SECOND PRIORITY] | [DATE] |
| 3 | [THIRD PRIORITY] | [DATE] |

---

## Notes for Next Week

[Anything the reader should know: upcoming PTO, dependencies, context for decisions you'll make — keep it brief.]

---

## Questions / Decisions Needed

- [ ] **[QUESTION]** — need answer from [NAME] by [DATE] to unblock [X]
- [ ] **[DECISION NEEDED]** — [CONTEXT AND OPTIONS]

*(Empty if none)*
