# INVOICE

---

**From:**  
[YOUR NAME / COMPANY NAME]  
[ADDRESS LINE 1]  
[CITY, POSTCODE, COUNTRY]  
[VAT NUMBER — if applicable]  
[EMAIL]  
[PHONE]  
[WEBSITE]

**To:**  
[CLIENT COMPANY NAME]  
[CONTACT NAME]  
[ADDRESS LINE 1]  
[CITY, POSTCODE, COUNTRY]  
[CLIENT VAT NUMBER — if applicable]

---

| | |
|--|--|
| **Invoice number:** | INV-[YEAR]-[NUMBER — e.g., 2024-001] |
| **Invoice date:** | [DATE] |
| **Due date:** | [DATE — typically 14 or 30 days] |
| **Project / Reference:** | [PROJECT NAME OR CONTRACT REF] |

---

## Services Rendered

| # | Description | Qty | Unit | Rate | Amount |
|---|-------------|-----|------|------|--------|
| 1 | [SERVICE DESCRIPTION — e.g., "Website redesign — Phase 1 (design)"] | [1] | project | €[RATE] | €[AMOUNT] |
| 2 | [SERVICE DESCRIPTION — e.g., "Consulting hours — April 2024"] | [X] | hours | €[HOURLY RATE] | €[AMOUNT] |
| 3 | [SERVICE DESCRIPTION] | [QTY] | [UNIT] | €[RATE] | €[AMOUNT] |

---

| | |
|--|--|
| **Subtotal:** | €[SUBTOTAL] |
| **VAT [X%]:** | €[VAT AMOUNT] |
| **Discount:** | -€[DISCOUNT — or "N/A"] |
| **Total due:** | **€[TOTAL]** |

---

## Payment Instructions

**Bank transfer (preferred):**
- Bank: [BANK NAME]
- Account holder: [NAME]
- IBAN: [IBAN]
- BIC/SWIFT: [BIC]
- Reference: [INVOICE NUMBER]

**Alternative payment:**
- [PAYPAL / STRIPE / OTHER: LINK OR EMAIL]

**Currency:** EUR (other currencies by arrangement)

---

## Terms

- Payment due within **[14 / 30] days** of invoice date
- Late payment: [X%] per month on outstanding balance after due date (where applicable by law)
- [Any project-specific terms — e.g., "Work remains property of [YOUR COMPANY] until payment is received in full"]

---

## Notes

[OPTIONAL: Thank you message, project notes, or next steps — e.g., "Thank you for a great project. Phase 2 kickoff is scheduled for [DATE]."]

---

*Questions about this invoice? Contact [EMAIL] or [PHONE].*

---

**[YOUR NAME / COMPANY NAME]**  
[DATE]  
[SIGNATURE if printing]
