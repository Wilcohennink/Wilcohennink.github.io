# SOP: Hiring & Interview Process

**Version:** 1.0  
**Owner:** [Hiring Manager / HR Lead]  
**Last updated:** [DATE]

---

## Purpose

A consistent, fair hiring process that identifies top candidates efficiently and creates a positive experience for all applicants.

---

## Roles & Responsibilities

| Stage | Owner |
|-------|-------|
| Job description + approval | [HIRING MANAGER + [ROLE]] |
| Job post publishing | [ROLE] |
| Application screening | [ROLE] |
| Interviews | [ROLE(S)] |
| Offer + negotiation | [ROLE] |
| Onboarding handoff | [ROLE] |

---

## Stage 1: Role Definition

Before posting, the hiring manager must document:

**Role Brief:**
```
Role title:
Team:
Reports to:
Reason for hire: [new headcount / backfill / contractor-to-hire]
Start date target:
Budget: €[MIN] – €[MAX] / year
Must-have skills (max 5):
1.
2.
3.
4.
5.
Nice-to-have skills:
Red flags to screen for:
Success looks like in 90 days:
```

**Approval required:** [MANAGER / CEO / FINANCE] sign-off before posting.

---

## Stage 2: Job Post

**Template:**

```markdown
# [JOB TITLE] at [COMPANY NAME]

[COMPANY NAME] is [ONE SENTENCE ABOUT WHAT YOU DO AND FOR WHOM].

We're looking for a [JOB TITLE] to [CORE MISSION IN ONE SENTENCE].

## What you'll do
- [RESPONSIBILITY 1 — use action verbs]
- [RESPONSIBILITY 2]
- [RESPONSIBILITY 3]
- [RESPONSIBILITY 4]
- [RESPONSIBILITY 5]

## What we're looking for
- [MUST-HAVE 1]
- [MUST-HAVE 2]
- [MUST-HAVE 3]
- [NICE-TO-HAVE — clearly label as "nice to have"]

## What we offer
- €[MIN] – €[MAX] salary
- [REMOTE / HYBRID / OFFICE] — [LOCATION if relevant]
- [BENEFIT 1 — e.g., "26 days PTO"]
- [BENEFIT 2 — e.g., "€1,000/year learning budget"]
- [BENEFIT 3]

## How to apply
Send your CV and a short (3-5 sentence) note answering:
**[SPECIFIC QUESTION — e.g., "What's the most complex project you've shipped and what was your role?"]**

to: [HIRING EMAIL]
```

**Post to:** [JOB BOARDS — e.g., LinkedIn, Indeed, Wellfound, company website]

---

## Stage 3: Screening

**SLA:** Review all applications within [X] business days of receipt.

**Screening scorecard:**

| Criterion | Weight | Score (1–5) |
|-----------|--------|-------------|
| Must-have skill match | 40% | |
| Relevant experience | 30% | |
| Application quality | 20% | |
| Culture signals | 10% | |

**Decision thresholds:**
- Score ≥ [X]: Advance to screen call
- Score [Y–X]: Hold for second opinion
- Score < [Y]: Decline (send template decline email within 5 business days)

**Decline email template:**
```
Subject: Re: Your application to [COMPANY]

Hi [NAME],

Thank you for applying for the [ROLE] position at [COMPANY].

After careful review, we've decided to move forward with other candidates whose background more closely matches our current needs. This was a competitive process and we appreciated your interest.

We'll keep your profile on file and may reach out if a relevant opportunity opens up.

Best of luck,
[YOUR NAME]
```

---

## Stage 4: Interview Process

### Round 1: Screen Call (30 min)

**Owner:** [RECRUITER / HIRING MANAGER]  
**Goal:** Confirm basics, assess communication, set expectations.

**Questions:**
1. Walk me through your background and what brought you to apply here.
2. What does your current role involve day-to-day?
3. Why are you looking to make a change now?
4. What do you know about [COMPANY]?
5. What are your compensation expectations?

**Go/No-go criteria:** [DEFINE WHAT ADVANCES A CANDIDATE]

---

### Round 2: Skills Assessment (60–90 min or take-home)

**Owner:** [TECHNICAL / FUNCTIONAL EXPERT]  
**Goal:** Verify core skills with a realistic, job-relevant task.

**Take-home task guidelines:**
- Time limit: [X hours] maximum
- Must be realistic and representative of actual work
- Compensate if task takes >2 hours: [€X honorarium / gift card]
- Evaluate on: [CRITERIA 1], [CRITERIA 2], [CRITERIA 3]

**Live assessment alternative:**
- [DESCRIBE LIVE EXERCISE if preferred]

---

### Round 3: Team Interview (60 min)

**Owner:** [TEAM MEMBERS WHO WILL WORK CLOSELY WITH THIS PERSON]  
**Goal:** Culture fit, collaboration style, deeper dive on experience.

**Questions (distribute across interviewers):**
1. Tell me about a time you disagreed with a decision. What did you do?
2. How do you prioritize when you have too much on your plate?
3. What kind of manager brings out your best work?
4. Describe a project that failed. What happened and what did you learn?
5. What would your last manager say is your biggest development area?

---

### Round 4: Final / Offer Stage (30 min)

**Owner:** [HIRING MANAGER / FOUNDER]  
**Goal:** Mutual commitment, address final concerns, present offer.

---

## Stage 5: Decision & Offer

**Decision meeting:**
- All interviewers submit scores via [TOOL] before the meeting
- 30-min debrief to reach consensus
- Document decision rationale in [ATS / HIRING TOOL]

**Offer letter must include:**
- Title, start date, salary, bonus (if applicable)
- Benefits summary
- Equity details (if applicable)
- Offer expiry: [X business days]
- Who to contact with questions

**Negotiation ceiling:** [HIRING MANAGER / FINANCE] must approve any salary above published range.

---

## Stage 6: Handoff to Onboarding

Once offer is accepted:
- [ ] Notify IT for access provisioning [X] days before start
- [ ] Assign onboarding buddy
- [ ] Send Day 1 logistics email
- [ ] Brief team on new hire's start date and role
- [ ] Hand off to Onboarding SOP: `sops/04-employee-onboarding-sop.md` (if applicable)

---

## Metrics to Track

| Metric | Target |
|--------|--------|
| Time to fill (posting → offer accepted) | < [X] days |
| Offer acceptance rate | > [X%] |
| Candidate NPS (post-process survey) | > [X] |
| Hiring manager satisfaction | > [X/5] |

---

## Version History

| Version | Date | Changed by | Change |
|---------|------|------------|--------|
| 1.0 | [DATE] | [NAME] | Initial version |
