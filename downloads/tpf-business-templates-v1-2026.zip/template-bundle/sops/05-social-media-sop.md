# SOP: Social Media Management

**Version:** 1.0  
**Owner:** [Social Media Manager / Marketing Lead]  
**Last updated:** [DATE]

---

## Purpose

Maintain a consistent, on-brand social presence that builds audience and drives traffic/leads without burning out the team.

---

## Channel Strategy

| Platform | Goal | Posting frequency | Format | Owner |
|----------|------|------------------|--------|-------|
| LinkedIn | Thought leadership, B2B leads | [X/week] | Long-form posts, carousels | [ROLE] |
| Twitter/X | Community, real-time engagement | [X/day] | Short posts, threads, replies | [ROLE] |
| Instagram | Brand awareness, lifestyle | [X/week] | Visual posts, stories, reels | [ROLE] |
| TikTok | Organic reach, demo content | [X/week] | Video (60-90 sec) | [ROLE] |
| YouTube | SEO, deeper content | [X/month] | Long-form video | [ROLE] |

---

## Weekly Content Schedule

| Day | Channel | Content Type | Who Creates | Who Posts |
|-----|---------|-------------|-------------|----------|
| Monday | LinkedIn | [TYPE] | [ROLE] | [ROLE] |
| Tuesday | Twitter/X | [TYPE] | [ROLE] | [ROLE] |
| Wednesday | Instagram | [TYPE] | [ROLE] | [ROLE] |
| Thursday | LinkedIn | [TYPE] | [ROLE] | [ROLE] |
| Friday | All channels | Weekly recap / light | [ROLE] | [ROLE] |

---

## Content Creation Process

### Step 1: Batch Creation (every [X] days)

- [ ] Pull from content bank ([NOTION / AIRTABLE / SHEETS LINK])
- [ ] Write [X] posts for next [X] days
- [ ] Create visuals in [CANVA / FIGMA] using brand templates
- [ ] Submit to [REVIEW TOOL] for approval

**Batch review SLA:** Approved within [X] business day(s) by [ROLE]

---

### Step 2: Scheduling

- [ ] Load approved posts into [SCHEDULING TOOL — e.g., Buffer, Later, Hootsuite]
- [ ] Set optimal post times per platform:
  - LinkedIn: [TIME — e.g., Tue/Thu 9am]
  - Instagram: [TIME]
  - Twitter/X: [TIME]
- [ ] Add UTM parameters to all links: `?utm_source=[PLATFORM]&utm_medium=social&utm_campaign=[CAMPAIGN]`

---

### Step 3: Engagement (daily, [X] minutes)

- [ ] Reply to all comments within [X] hours
- [ ] Like and reply to relevant mentions and tags
- [ ] Engage with [X] posts from target accounts / partners
- [ ] Log any DMs that need follow-up in [CRM / TOOL]

---

## Post Templates

### LinkedIn Text Post
```
[HOOK — bold claim, counterintuitive statement, or "I used to think X"]

[STORY or DATA that supports the hook — 3-5 short paragraphs]

[INSIGHT — what changed, what you learned]

[PRACTICAL TAKEAWAY — what the reader should do]

[CALL TO ACTION — question to drive comments, or soft link to product]

#[HASHTAG1] #[HASHTAG2] #[HASHTAG3]
```

### Twitter/X Thread
```
Tweet 1: [HOOK — your most surprising/bold claim] 🧵

Tweet 2: [CONTEXT — why this matters]

Tweet 3-8: [THE MEAT — numbered points, each self-contained]

Tweet 9: [SUMMARY]

Tweet 10: [CTA — follow, link, or question]
```

### Instagram Caption
```
[HOOK — first line must stop the scroll]

[2-3 sentences of context or story]

[CALL TO ACTION — "save this", "tag someone", "link in bio"]

.
.
.
[HASHTAGS — 5-10, in first comment or below the dots]
```

---

## Brand Voice Guidelines

- **Tone:** [DESCRIBE — e.g., "Direct and confident, with occasional dry humor. Not corporate."]
- **Always:** [MANDATORY TONE ELEMENT — e.g., "Use specific numbers, not vague claims"]
- **Never:** [PROHIBITED — e.g., "Inspirational fluff without substance", "Excessive emoji"]
- **Point of view:** [FIRST PERSON / BRAND VOICE / BOTH]

---

## Crisis & Sensitive Content Protocol

**If negative comment or PR issue:**
1. Do NOT delete comments (unless violates platform rules or is spam)
2. Do NOT respond immediately — escalate to [ROLE] first
3. Draft response, have [MANAGER] approve before posting
4. Response window: [X] hours

**Topics to avoid / run by legal:**
- [TOPIC 1]
- [TOPIC 2]
- Any statement about competitors

---

## Metrics & Reporting

**Track weekly:**
- Follower growth by platform
- Impressions and reach
- Engagement rate (target: >[X%])
- Clicks to website (UTM tracked)
- DMs / leads generated

**Monthly report due:** [DAY] of each month to [ROLE/STAKEHOLDER]  
**Reporting tool:** [ANALYTICS PLATFORM / DASHBOARD LINK]

---

## Access & Tools

| Tool | Purpose | Login stored at |
|------|---------|----------------|
| [SCHEDULING TOOL] | Post scheduling | [PASSWORD MANAGER] |
| [ANALYTICS TOOL] | Performance tracking | [PASSWORD MANAGER] |
| [DESIGN TOOL] | Visual content | [PASSWORD MANAGER] |
| [BRAND ASSET FOLDER] | Logos, templates, fonts | [LINK] |

---

## Version History

| Version | Date | Changed by | Change |
|---------|------|------------|--------|
| 1.0 | [DATE] | [NAME] | Initial version |
