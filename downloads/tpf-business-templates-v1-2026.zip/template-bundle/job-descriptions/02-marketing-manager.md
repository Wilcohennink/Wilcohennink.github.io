# Job Description: Marketing Manager

**Company:** [COMPANY NAME]  
**Location:** [CITY / Remote / Hybrid]  
**Type:** Full-time  
**Salary:** €[MIN] – €[MAX] per year  
**Reports to:** [CMO / CEO / HEAD OF GROWTH]

---

## About [COMPANY NAME]

[2-3 sentences about the company, product, mission, and proof of traction.]

---

## The Role

We're looking for a Marketing Manager to [CORE MISSION — e.g., "own our content and demand generation strategy from planning to execution"]. 

This is a [GENERALIST / SPECIALIST] role — you'll be responsible for [SCOPE — e.g., "everything from writing our newsletter to running paid campaigns and coordinating external agencies"]. 

In the first 90 days, your top priority will be [SPECIFIC 90-DAY OBJECTIVE].

---

## What You'll Do

- **Content:** [e.g., "Create and manage the editorial calendar — blog, newsletter, social (2,000+ subscribers and growing)"]
- **Demand generation:** [e.g., "Plan and execute campaigns across email, paid, and organic channels to hit monthly MQL targets"]
- **SEO:** [e.g., "Own keyword strategy and on-page SEO to grow organic traffic from X to Y visits/month"]
- **Analytics:** [e.g., "Track, report on, and optimize key marketing metrics weekly"]
- **Partnerships:** [e.g., "Identify and manage co-marketing and affiliate partnerships"]
- **Brand:** [e.g., "Maintain brand consistency across all customer touchpoints"]

---

## What We're Looking For

**Must-have:**
- [X]+ years in a B2B / B2C marketing role (adjust to your context)
- Proven experience growing an [email list / organic channel / paid acquisition]
- Strong writer — you can produce first drafts that need minimal editing
- Data-driven: comfortable in [ANALYTICS TOOL — e.g., Google Analytics, Mixpanel] and making decisions from data
- [SPECIFIC SKILL — e.g., "Experience with email platforms like Mailchimp, Beehiiv, or ConvertKit"]

**Nice-to-have:**
- Experience in [YOUR INDUSTRY]
- [ADDITIONAL SKILL — e.g., "Basic design skills in Canva or Figma"]
- [ADDITIONAL SKILL]

---

## What We Offer

- **Salary:** €[MIN] – €[MAX]
- **Equity:** [X]% (if applicable)
- **Remote:** [POLICY]
- **Budget:** €[X]/month for tools and campaigns you manage directly
- **PTO:** [X] days
- **Learning:** €[X]/year
- **[OTHER BENEFIT]**

---

## Interview Process

1. Application review ([X] business days response)
2. 30-min screen call
3. Take-home assignment (~2 hours): [DESCRIBE — e.g., "Write a short content brief and one sample LinkedIn post based on a brief we provide"]
4. 60-min team interview
5. Offer

---

## How to Apply

Email [EMAIL] with subject: **"Marketing Manager — [YOUR NAME]"**

Include: CV + your answer to: **"What's a marketing campaign or piece of content you're most proud of, and what made it work?"**

*[COMPANY] is an equal opportunity employer.*
