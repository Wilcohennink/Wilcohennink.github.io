# OKRs: [TEAM / COMPANY NAME] — [QUARTER] [YEAR]

**Owner:** [NAME]  
**Set on:** [DATE]  
**Review cadence:** Weekly check-in, monthly deep-dive  
**End-of-quarter review:** [DATE]

---

## How We Use OKRs

- **Objectives** are qualitative and inspirational. They answer "where do we want to go?"
- **Key Results** are quantitative. They answer "how will we know we got there?"
- Each KR is scored 0.0–1.0 at quarter-end. Target is 0.7 (not 1.0 — if you always hit 1.0, you're not setting ambitious enough goals)

---

## Objective 1: [OBJECTIVE STATEMENT]

*Why this matters: [1-2 sentences on why this objective is important this quarter]*

| Key Result | Owner | Baseline | Target | Week 4 | Week 8 | Week 12 | Final |
|------------|-------|----------|--------|--------|--------|---------|-------|
| KR1.1: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |
| KR1.2: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |
| KR1.3: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |

**Objective score (end of quarter):** __ / 1.0

**Key initiatives this quarter:**
- [INITIATIVE 1 — the main projects/bets under this objective]
- [INITIATIVE 2]
- [INITIATIVE 3]

---

## Objective 2: [OBJECTIVE STATEMENT]

*Why this matters: [1-2 sentences]*

| Key Result | Owner | Baseline | Target | Week 4 | Week 8 | Week 12 | Final |
|------------|-------|----------|--------|--------|--------|---------|-------|
| KR2.1: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |
| KR2.2: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |
| KR2.3: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |

**Objective score (end of quarter):** __ / 1.0

**Key initiatives:**
- [INITIATIVE 1]
- [INITIATIVE 2]

---

## Objective 3: [OBJECTIVE STATEMENT]

*Why this matters: [1-2 sentences]*

| Key Result | Owner | Baseline | Target | Week 4 | Week 8 | Week 12 | Final |
|------------|-------|----------|--------|--------|--------|---------|-------|
| KR3.1: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |
| KR3.2: [METRIC] from [X] to [Y] | [NAME] | [X] | [Y] | | | | |

**Objective score (end of quarter):** __ / 1.0

**Key initiatives:**
- [INITIATIVE 1]
- [INITIATIVE 2]

---

## What We're NOT Doing This Quarter

*(Important: explicitly state the things you're deprioritizing to make focus possible)*

- [THING YOU WILL NOT DO OR FOCUS ON]
- [THING YOU WILL NOT DO OR FOCUS ON]
- [THING YOU WILL NOT DO OR FOCUS ON]

---

## Risks & Dependencies

| Risk | Impact | Mitigation |
|------|--------|-----------|
| [RISK] | [WHICH OKR IT THREATENS] | [MITIGATION] |
| [RISK] | [IMPACT] | [MITIGATION] |

---

## End-of-Quarter Retrospective

*(Fill in at quarter end)*

**Overall score:** __ / 1.0

**What went well:**
- 

**What didn't work:**
- 

**What we're carrying forward:**
- 

**What we're dropping:**
- 

**Input for next quarter's OKRs:**
- 
