# SOP: Content Creation & Publication

**Version:** 1.0  
**Owner:** [Content Lead / Marketing Manager]  
**Last updated:** [DATE]  
**Applies to:** Blog posts, newsletters, social content, case studies

---

## Purpose

To produce consistent, high-quality content on schedule, with a repeatable process from idea to publish.

---

## Content Types & Owners

| Type | Owner | Frequency | Lead time needed |
|------|-------|-----------|-----------------|
| Blog post | [ROLE] | [X/month] | 7 days |
| Newsletter | [ROLE] | [X/week] | 3 days |
| LinkedIn post | [ROLE] | [X/week] | 1 day |
| Case study | [ROLE] | [X/quarter] | 14 days |

---

## Process: Blog Post

### Step 1: Ideation & Approval (Day -7)

- [ ] Submit title + 3-sentence pitch to content calendar ([TOOL LINK])
- [ ] Owner approves or requests changes (within 1 business day)
- [ ] Keyword research completed and documented ([TOOL — e.g., Ahrefs/Semrush])
- [ ] Target keyword, search volume, and difficulty logged in content tracker

**Brief template:**

```
Title: 
Target keyword: 
Search intent: [informational / commercial / navigational]
Target reader: [PERSONA]
Main argument in 1 sentence:
Top 3 points to cover:
1.
2.
3.
Competing articles to beat: [URLs]
```

---

### Step 2: Draft (Day -5)

- [ ] First draft written using brief
- [ ] Minimum length: [X words]
- [ ] Structure: H1 → intro → [X subheadings] → conclusion → CTA
- [ ] Internal links: minimum [X] links to existing content
- [ ] External links: [X] credible sources
- [ ] Draft submitted to [REVIEW TOOL — e.g., Google Docs, Notion] and tagged for review

**Quality bar:**
- Grammarly score: [X]+
- Flesch Reading Ease: [X]+
- No passive voice >10% of sentences

---

### Step 3: Review & Edit (Day -3)

- [ ] Editor reviews for: accuracy, tone, structure, SEO
- [ ] Feedback given in [TOOL] using comments (no direct edits)
- [ ] Author revises based on feedback
- [ ] Final approval from [ROLE] (1 business day SLA)

---

### Step 4: Production (Day -1)

- [ ] Upload to [CMS — e.g., WordPress, Webflow, Ghost]
- [ ] SEO fields: title tag, meta description, slug, alt text on images
- [ ] Featured image: [SIZE] px, saved as [webp/jpg], max [X] KB
- [ ] Set publish date/time: [DEFAULT PUBLISH TIME — e.g., Tuesday 9am CET]
- [ ] Internal review of live preview before scheduling

---

### Step 5: Publish & Distribute

**On publish day:**
- [ ] [CMS] post published
- [ ] Newsletter excerpt sent to [SEGMENT] (if applicable)
- [ ] LinkedIn post published (link + 3-5 key points from the article)
- [ ] Twitter/X thread published (if applicable)
- [ ] Add to [INTERNAL SLACK CHANNEL] for team visibility

**Within 48 hours:**
- [ ] Check: Google Search Console indexed
- [ ] Log final URL in content tracker with publish date and target keyword

---

## Process: Newsletter

### Step 1: Outline (Day -3)
- [ ] Pull 3 links from [READING LIST / BOOKMARKS TOOL]
- [ ] Identify main topic from content calendar
- [ ] Write 5-bullet outline

### Step 2: Draft (Day -2)
- [ ] Write draft using template: `email-templates/08-newsletter-template.html`
- [ ] Subject line options: write 3, pick 1 ([A/B TEST if list >1,000])

### Step 3: Send Prep (Day -1)
- [ ] Load into [EMAIL TOOL — e.g., Mailchimp, Beehiiv, ConvertKit]
- [ ] Send test to [TEST SEGMENT / INTERNAL LIST]
- [ ] Check: links work, images load, unsubscribe works
- [ ] Schedule for [DEFAULT TIME — e.g., Thursday 7am CET]

---

## Tools Stack

| Tool | Purpose | Access |
|------|---------|--------|
| [TOOL] | Keyword research | [URL / LOGIN LOCATION] |
| [TOOL] | Writing + drafting | [URL] |
| [TOOL] | CMS / publishing | [URL] |
| [TOOL] | Email sending | [URL] |
| [TOOL] | Content calendar | [URL] |
| [TOOL] | Analytics | [URL] |

---

## Content Standards

- **Voice:** [DESCRIBE YOUR BRAND VOICE — e.g., "Direct, opinionated, data-driven. No fluff."]
- **Always include:** [MANDATORY ELEMENT — e.g., "One original stat or insight"]
- **Never include:** [PROHIBITED — e.g., "Passive voice, clichés, AI-generated text without heavy editing"]
- **CTA standard:** Every piece ends with one clear CTA: [WHAT ACTION YOU WANT]

---

## Version History

| Version | Date | Changed by | Change |
|---------|------|------------|--------|
| 1.0 | [DATE] | [NAME] | Initial version |
