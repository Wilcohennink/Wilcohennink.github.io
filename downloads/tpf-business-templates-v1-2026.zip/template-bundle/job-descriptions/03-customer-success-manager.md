# Job Description: Customer Success Manager

**Company:** [COMPANY NAME]  
**Location:** [CITY / Remote / Hybrid]  
**Type:** Full-time  
**Salary:** €[MIN] – €[MAX] + [BONUS/COMMISSION STRUCTURE]  
**Reports to:** [HEAD OF CS / VP SALES / CEO]

---

## About [COMPANY NAME]

[2-3 sentences about company, product, and current customer base size.]

---

## The Role

As our Customer Success Manager, you'll be the primary point of contact for [X] accounts totaling [€X ARR / X customers]. Your goal is simple: make customers successful enough that they stay and grow.

You'll be responsible for [SCOPE — e.g., "onboarding new customers, driving adoption, managing renewals, and identifying expansion opportunities"].

---

## What You'll Do

- **Onboarding:** Guide new customers through implementation from contract signature to first value (use our SOP: goal is [X-day time-to-value])
- **Adoption:** Proactively monitor usage data and reach out to customers showing risk signals
- **QBRs:** Run quarterly business reviews with [X]+ accounts — come prepared with data, leave with clear next steps
- **Renewals:** Own your renewal pipeline — forecast accurately, negotiate renewals, minimize churn
- **Expansion:** Identify upsell and cross-sell opportunities organically through relationship
- **Voice of customer:** Collect and synthesize customer feedback to share with Product and leadership

---

## What We're Looking For

**Must-have:**
- [X]+ years in a customer success, account management, or customer-facing role
- Experience managing [SMB / Mid-market / Enterprise] accounts
- Strong written and verbal communication — you run customer meetings confidently and write clearly
- Organized and process-driven — you know how to manage a high-volume account list without things falling through the cracks
- Data-driven — comfortable reading dashboards and using data to drive customer conversations

**Nice-to-have:**
- Experience in [YOUR INDUSTRY]
- Familiarity with [YOUR PRODUCT CATEGORY]
- [CS TOOL EXPERIENCE — e.g., Gainsight, ChurnZero, Intercom]

---

## Metrics You'll Own

| Metric | Target |
|--------|--------|
| Net Revenue Retention (NRR) | [X%]+ |
| Gross Revenue Retention (GRR) | [X%]+ |
| Time-to-value (onboarding) | [X days] |
| CSAT / NPS | [X]+ |
| QBR completion rate | [X%] |

---

## What We Offer

- **Salary:** €[MIN] – €[MAX] base
- **Variable:** €[X] OTE on top of base ([BONUS STRUCTURE])
- **Equity:** [X]% (if applicable)
- **Remote:** [POLICY]
- **PTO:** [X] days
- **Tools:** Full stack provided ([LIST KEY TOOLS])
- **[OTHER BENEFIT]**

---

## Interview Process

1. Application review
2. 30-min screen call
3. Role-play exercise (~45 min): [DESCRIBE — e.g., "Handle a mock QBR with an at-risk customer"]
4. Team interview (60 min)
5. Offer

---

## How to Apply

Send CV to [EMAIL] with subject: **"CSM Role — [YOUR NAME]"**

Answer in 3-5 sentences: **"Tell me about a customer you saved from churning. What happened and what did you do?"**

*[COMPANY] is an equal opportunity employer.*
