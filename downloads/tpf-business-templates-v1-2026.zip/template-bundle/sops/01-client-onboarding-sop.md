# SOP: Client Onboarding Process

**Version:** 1.0  
**Owner:** [ROLE — e.g., Account Manager / Operations Lead]  
**Last updated:** [DATE]  
**Review cycle:** Quarterly

---

## Purpose

This SOP ensures every new client receives a consistent, professional onboarding experience that sets clear expectations, minimizes confusion, and accelerates time-to-value.

## Scope

Applies to all new clients from the moment a contract is signed through the end of the first 30 days.

## Responsible Roles

| Step | Owner |
|------|-------|
| Contract → kickoff | [ROLE] |
| Technical setup | [ROLE] |
| Training | [ROLE] |
| Check-in calls | [ROLE] |

---

## Process

### Stage 1: Contract Signed (Day 0)

**Trigger:** Signed contract received AND deposit payment confirmed.

**Within 2 business hours:**
- [ ] Send welcome email (use template: `email-templates/02-onboarding-sequence.html`)
- [ ] Create client folder in [DRIVE / PROJECT MANAGEMENT TOOL] using naming format: `[COMPANY-NAME]_[YYYY-MM]`
- [ ] Add client to CRM with status: `Onboarding`
- [ ] Assign dedicated [ACCOUNT MANAGER / CSM] in CRM
- [ ] Create kick-off meeting invite for [X business days from now]

**Within 24 hours:**
- [ ] Send client onboarding questionnaire (link: [FORM URL])
- [ ] Set up [SLACK / TEAMS] channel named `[CLIENT-NAME]-project`
- [ ] Add client contacts to [COMMUNICATION CHANNEL]

---

### Stage 2: Kickoff Call (Day 2–3)

**Preparation (day before kickoff):**
- [ ] Review completed onboarding questionnaire
- [ ] Prepare kickoff deck (template: [LINK])
- [ ] Identify any blockers or missing information

**During the call (60 minutes):**
- [ ] Introductions (10 min)
- [ ] Review project goals and success metrics (15 min)
- [ ] Walk through timeline and milestones (10 min)
- [ ] Cover communication norms: cadence, channels, response times (10 min)
- [ ] Q&A and alignment (15 min)

**Within 24 hours post-call:**
- [ ] Send meeting recap with decisions, action items, and owners
- [ ] Update project management tool with agreed milestones
- [ ] Send any assets or access credentials requested on call

---

### Stage 3: Technical Setup (Day 3–7)

- [ ] [SETUP STEP 1 — e.g., "Provision client account in system"]
- [ ] [SETUP STEP 2 — e.g., "Configure integrations per their tech stack"]
- [ ] [SETUP STEP 3 — e.g., "Run data migration if applicable"]
- [ ] Confirm all setup with client via email
- [ ] Conduct 30-min walkthrough/training session

**Handoff checklist before training:**
- [ ] All credentials delivered to client
- [ ] Test environment verified working
- [ ] Known limitations or gotchas documented and shared

---

### Stage 4: Training (Day 7–14)

- [ ] Schedule training session(s) — [X hour(s)] for [NUMBER OF USERS]
- [ ] Deliver training using [TOOL — e.g., Zoom + Loom recording]
- [ ] Share recording and training materials within 24 hours
- [ ] Confirm client team members are confident with core workflows

**Training confirmation email includes:**
- Recording link
- Quick-reference guide (template: [LINK])
- How to get help: [SUPPORT EMAIL / CHANNEL / DOCS URL]

---

### Stage 5: 30-Day Check-In (Day 28–30)

**Goal:** Confirm value delivered, identify friction, and set the stage for long-term success.

**Agenda (30 minutes):**
- What's working well?
- What's still unclear or frustrating?
- Have they hit [CORE SUCCESS METRIC]?
- Introduce any relevant features they haven't used

**Post-call:**
- [ ] Log notes in CRM
- [ ] If concerns raised: create internal issue and assign owner with [X]-day resolution SLA
- [ ] Update client status to `Active` (from `Onboarding`) in CRM
- [ ] Schedule next QBR or check-in for [DATE]

---

## Quality Gates

Do not proceed past Stage 2 until:
- [ ] Onboarding questionnaire 100% complete
- [ ] Payment confirmed
- [ ] Primary contact and decision-maker identified

Do not close onboarding until:
- [ ] Client confirms they've successfully completed [CORE USE CASE]
- [ ] No open support tickets older than [X] business days

---

## Escalation

If a client is not responding within [X business days] at any stage:
1. Send follow-up email from this template: [LINK]
2. If still no response after [X more days]: escalate to [MANAGER ROLE]
3. Log in CRM as `At Risk`

---

## Tools & Templates Referenced

| Resource | Location |
|----------|----------|
| Kickoff deck template | [LINK] |
| Onboarding questionnaire | [LINK] |
| Welcome email | `email-templates/02-onboarding-sequence.html` |
| Training recording SOP | [LINK] |
| CRM onboarding stage guide | [LINK] |

---

## Version History

| Version | Date | Changed by | Change |
|---------|------|------------|--------|
| 1.0 | [DATE] | [NAME] | Initial version |
