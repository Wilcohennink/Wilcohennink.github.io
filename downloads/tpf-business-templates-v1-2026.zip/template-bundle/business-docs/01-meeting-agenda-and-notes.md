# Meeting Template: [MEETING NAME]

**Date:** [DATE]  
**Time:** [TIME] [TIMEZONE]  
**Location:** [ROOM / VIDEO LINK]  
**Duration:** [X] minutes  
**Facilitator:** [NAME]  
**Note-taker:** [NAME]

---

## Attendees

| Name | Role | Required? |
|------|------|-----------|
| [NAME] | [ROLE] | Yes |
| [NAME] | [ROLE] | Yes |
| [NAME] | [ROLE] | Optional |

---

## Agenda

| # | Topic | Owner | Time |
|---|-------|-------|------|
| 1 | [TOPIC] | [NAME] | [X] min |
| 2 | [TOPIC] | [NAME] | [X] min |
| 3 | [TOPIC] | [NAME] | [X] min |
| 4 | Wrap-up / action items | All | 5 min |

**Parking lot:** (Topics raised but not on agenda — to be scheduled separately)

---

## Pre-Meeting Prep

For all attendees:
- [ ] [READ THIS DOCUMENT / REVIEW THIS DATA — link]
- [ ] [COME PREPARED WITH — specific input requested]

---

## Notes

### Item 1: [TOPIC]

**Discussion:**  
[Notes]

**Decision:**  
[Decision made, if any]

---

### Item 2: [TOPIC]

**Discussion:**  
[Notes]

**Decision:**  
[Decision made, if any]

---

### Item 3: [TOPIC]

**Discussion:**  
[Notes]

**Decision:**  
[Decision made, if any]

---

## Action Items

| # | Action | Owner | Due date | Status |
|---|--------|-------|----------|--------|
| 1 | [ACTION] | [NAME] | [DATE] | Open |
| 2 | [ACTION] | [NAME] | [DATE] | Open |
| 3 | [ACTION] | [NAME] | [DATE] | Open |

---

## Decisions Log

| Decision | Rationale | Made by | Date |
|----------|-----------|---------|------|
| [DECISION] | [WHY] | [NAME/GROUP] | [DATE] |

---

## Next Meeting

**Date:** [DATE]  
**Agenda (draft):**  
- Follow up on: [ACTION ITEMS FROM TODAY]
- New items: [TOPICS]

---

*Notes distributed to: [LIST / MAILING LIST] within [X] hours of meeting.*
